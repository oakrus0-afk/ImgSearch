# ImgSearch — fast image search

This build focuses on the search functionality described in the requested backend/search specification.

## Stack
- JavaScript (browser ES modules)
- Wikimedia Commons MediaWiki Action API
- No API key required

## Search behavior
- 450 ms debounce for typing-driven search.
- Query sanitization and normalization.
- Wikimedia Commons image-only search (`filetype:bitmap|drawing`).
- Relevance ranking using title, aliases, tags/labels and description when available.
- Presentation terms such as `avatar`, `portrait`, `wallpaper` refine a query but do not make the entity mandatory.
- Entity spelling variants for common `Spider-Man` / `Spiderman` input.
- Pagination using `gsroffset` + `gsrlimit`.
- 500px thumbnails for the result grid.
- The original high-resolution file URL is fetched only when a result is opened.
- Duplicate/seen-result filtering in local storage.
- Abortable requests and a 5 second timeout.
- Structured search responses are represented by `SearchCore.createSearchResponse()`.

## Example
`Spiderman Avatar` is treated as an entity query for Spider-Man plus an optional presentation preference. A result does not have to contain the literal word `avatar` to be considered relevant.

## JSON shape
The search layer returns the equivalent of:

```json
{
  "ok": true,
  "query": "spiderman avatar",
  "page": 0,
  "pageSize": 24,
  "hasMore": true,
  "results": [
    {
      "id": "...",
      "previewUrl": "https://...",
      "originalUrl": null,
      "sourceUrl": "https://...",
      "alt": "...",
      "title": "...",
      "description": "...",
      "tags": [],
      "width": 500,
      "height": 500,
      "provider": "commons"
    }
  ]
}
```

`originalUrl` stays null during search and is resolved only on selection.
