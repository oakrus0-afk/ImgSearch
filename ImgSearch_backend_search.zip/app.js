import * as SearchCore from "./search-core.js";

const COMMONS_API = "https://commons.wikimedia.org/w/api.php";
const PAGE_SIZE = 24;
const DISPLAY_BATCH = 8;
const REQUEST_TIMEOUT = 5000;
const DEBOUNCE_MS = 450;
const STORAGE_KEY = "imgsearch_seen_v3";

const I18N = {
  en: {
    navSearch: "Search", navAbout: "About", navCta: "Find images",
    eyebrow: "Open-source image discovery",
    heroTitle: "Find your<br><em>next</em> image.",
    heroCopy: "Search a theme, character, mood or style. ImgSearch returns fast, relevance-ranked results from Wikimedia Commons.",
    searchLabel: "What are you looking for?", searchPlaceholder: "Spider-Man avatar, cyberpunk cat, red car...",
    searchButton: "Search", resultsEyebrow: "Results", resultsTitle: "Your results.", moreButton: "More images",
    aboutTitle: "Focused search.<br><em>Less noise.</em>",
    aboutCopy: "The search layer sanitizes queries, ranks title/alias/tag/description matches, paginates results and keeps original files out of the critical preview request.",
    aboutSmall: "Source: Wikimedia Commons MediaWiki API. Preview thumbnails are requested for the result grid; the original file URL is fetched only when an image is opened.",
    footer: "Fast search · relevance-ranked results · Wikimedia Commons",
    idleMeta: "Ready to search", searching: "Searching…", looking: "Searching Wikimedia Commons…",
    empty: "Nothing relevant was found. Try a broader query.", error: "The image source did not respond. Please try again.",
    invalid: "Enter a search query first.", more: "More images", source: "Open source ↗"
  },
  ru: {
    navSearch: "Поиск", navAbout: "О проекте", navCta: "Найти изображения",
    eyebrow: "Быстрый поиск изображений из открытого источника",
    heroTitle: "Найди своё<br><em>новое</em> изображение.",
    heroCopy: "Ищи тему, персонажа, настроение или стиль. ImgSearch быстро выдаёт релевантные результаты из Wikimedia Commons.",
    searchLabel: "Что ищем?", searchPlaceholder: "Spider-Man avatar, киберпанк кот, красная машина...",
    searchButton: "Поиск", resultsEyebrow: "Результаты", resultsTitle: "Твои результаты.", moreButton: "Ещё изображения",
    aboutTitle: "Точный поиск.<br><em>Меньше мусора.</em>",
    aboutCopy: "Поисковый слой очищает запрос, ранжирует совпадения по названию, псевдонимам, тегам и описанию, использует пагинацию и не загружает оригиналы в основном поисковом запросе.",
    aboutSmall: "Источник: Wikimedia Commons MediaWiki API. Для сетки запрашиваются только превью; ссылка на оригинальный файл получается только при открытии изображения.",
    footer: "Быстрый поиск · релевантность · Wikimedia Commons",
    idleMeta: "Готов к поиску", searching: "Поиск…", looking: "Ищем в Wikimedia Commons…",
    empty: "Ничего достаточно релевантного не найдено. Попробуй более широкий запрос.", error: "Источник изображений не ответил. Попробуй ещё раз.",
    invalid: "Сначала введи запрос.", more: "Ещё изображения", source: "Открыть источник ↗"
  }
};

let lang = localStorage.getItem("imgsearch_lang") || "ru";
let currentQuery = "";
let currentPage = 0;
let hasMore = false;
let requestId = 0;
let abortController = null;
let debounceTimer = null;
let seen = loadSeen();

const form = document.getElementById("searchForm");
const input = document.getElementById("query");
const searchButton = document.getElementById("searchButton");
const moreButton = document.getElementById("moreButton");
const grid = document.getElementById("resultsGrid");
const title = document.getElementById("resultsTitle");
const meta = document.getElementById("resultMeta");
const statusBox = document.getElementById("status");
const template = document.getElementById("cardTemplate");

function t(key, ...args) {
  const value = I18N[lang][key];
  return typeof value === "function" ? value(...args) : value;
}

function applyLanguage() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach(el => el.textContent = t(el.dataset.i18n));
  document.querySelectorAll("[data-i18n-html]").forEach(el => el.innerHTML = t(el.dataset.i18nHtml));
  document.querySelectorAll("[data-i18n-placeholder]").forEach(el => el.placeholder = t(el.dataset.i18nPlaceholder));
  document.querySelectorAll(".lang").forEach(btn => {
    const active = btn.dataset.lang === lang;
    btn.classList.toggle("active", active);
    btn.setAttribute("aria-pressed", active ? "true" : "false");
  });
  document.title = lang === "ru" ? "ImgSearch — поиск изображений" : "ImgSearch — image discovery";
  if (!currentQuery) meta.textContent = t("idleMeta");
}

function loadSeen() {
  try {
    const value = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
    return value && typeof value === "object" ? value : {};
  } catch { return {}; }
}
function saveSeen() { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(seen)); } catch {} }
function itemKey(item) { return item.id ? `${item.provider}:${item.id}` : item.previewUrl; }
function isSeen(item) { return Boolean(seen[itemKey(item)]); }
function markSeen(item) { seen[itemKey(item)] = Date.now(); saveSeen(); }

function setStatus(message) {
  statusBox.textContent = message || "";
  statusBox.hidden = !message;
}
function setLoading(loading) {
  searchButton.disabled = loading;
  searchButton.setAttribute("aria-busy", loading ? "true" : "false");
}

function withTimeout(task, parentSignal, ms) {
  const controller = new AbortController();
  const relay = () => controller.abort(parentSignal.reason);
  if (parentSignal.aborted) controller.abort(parentSignal.reason);
  else parentSignal.addEventListener("abort", relay, { once: true });

  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => controller.abort(new DOMException("Request timed out", "TimeoutError")), ms);
    task(controller.signal).then(resolve, reject).finally(() => {
      clearTimeout(timer);
      parentSignal.removeEventListener("abort", relay);
    });
  });
}

function buildCommonsUrl(query, page = 0) {
  const url = new URL(COMMONS_API);
  const params = {
    action: "query",
    generator: "search",
    gsrsearch: `${query} filetype:bitmap|drawing`,
    gsrnamespace: "6",
    gsrlimit: String(PAGE_SIZE),
    gsroffset: String(page * PAGE_SIZE),
    prop: "info|imageinfo|pageterms",
    inprop: "url",
    iiprop: "url|size|mime",
    iiurlwidth: "500",
    wbptterms: "label|description|alias",
    format: "json",
    formatversion: "2",
    origin: "*"
  };
  Object.entries(params).forEach(([key, value]) => url.searchParams.set(key, value));
  return url;
}

async function fetchCommonsPage(query, page, signal) {
  const response = await fetch(buildCommonsUrl(query, page), {
    signal,
    headers: { Accept: "application/json" }
  });
  if (!response.ok) throw new Error(`Wikimedia HTTP ${response.status}`);
  const data = await response.json();
  if (data.error) throw new Error(data.error.info || "Wikimedia API error");

  const pages = data.query?.pages || [];
  const items = pages.map(pageData => {
    const info = pageData.imageinfo?.[0];
    if (!info?.url || !info?.thumburl || !/^image\//i.test(info.mime || "image")) return null;
    const terms = pageData.terms || {};
    const labels = terms.label || [];
    const descriptions = terms.description || [];
    const aliases = terms.alias || [];
    const title = String(pageData.title || "Image").replace(/^File:/i, "");
    return {
      provider: "commons",
      id: String(pageData.pageid || title),
      title,
      description: descriptions.join(" "),
      tags: labels,
      aliases,
      previewUrl: info.thumburl,
      originalUrl: null,
      sourceUrl: pageData.fullurl || `https://commons.wikimedia.org/wiki/${encodeURIComponent(pageData.title || "")}`,
      width: Number(info.width) || 0,
      height: Number(info.height) || 0,
      mime: info.mime || "image/*",
      alt: descriptions[0] || title
    };
  }).filter(Boolean);

  return {
    items,
    hasMore: Boolean(data.continue?.gsroffset || data.continue)
  };
}

async function fetchOriginalUrl(item, signal) {
  if (item.originalUrl) return item.originalUrl;
  const url = new URL(COMMONS_API);
  url.searchParams.set("action", "query");
  url.searchParams.set("titles", `File:${item.title}`);
  url.searchParams.set("prop", "imageinfo");
  url.searchParams.set("iiprop", "url");
  url.searchParams.set("format", "json");
  url.searchParams.set("formatversion", "2");
  url.searchParams.set("origin", "*");

  const response = await withTimeout(s => fetch(url, { signal: s, headers: { Accept: "application/json" } }), signal, REQUEST_TIMEOUT);
  if (!response.ok) throw new Error(`Wikimedia HTTP ${response.status}`);
  const data = await response.json();
  return data.query?.pages?.[0]?.imageinfo?.[0]?.url || item.sourceUrl;
}

async function searchPage(query, page, signal) {
  const variants = SearchCore.buildSearchQueries(query);
  let lastError = null;
  for (let i = 0; i < variants.length; i++) {
    try {
      const result = await withTimeout(s => fetchCommonsPage(variants[i], page, s), signal, REQUEST_TIMEOUT);
      const ranked = SearchCore.rankItems(result.items, query);
      if (ranked.length || i === variants.length - 1) {
        return { ...result, items: ranked, usedQuery: variants[i] };
      }
    } catch (error) {
      if (error.name === "AbortError") throw error;
      lastError = error;
    }
  }
  throw lastError || new Error("No search result");
}

function renderCards(items) {
  const frag = document.createDocumentFragment();
  for (const item of items) {
    const node = template.content.cloneNode(true);
    const card = node.querySelector(".avatar-card");
    const wrap = node.querySelector(".image-wrap");
    const img = node.querySelector("img");
    const imageLink = node.querySelector(".image-link");
    const sourceLink = node.querySelector(".source-link");
    const titleNode = node.querySelector(".card-title");

    img.src = item.previewUrl;
    img.alt = item.alt || item.title;
    imageLink.href = item.sourceUrl;
    imageLink.dataset.id = item.id;
    sourceLink.href = item.sourceUrl;
    sourceLink.textContent = t("source");
    titleNode.textContent = item.title.replace(/\s+/g, " ").trim().slice(0, 120);
    node.querySelector(".license").textContent = "Wikimedia Commons";
    node.querySelector(".source-pill").textContent = "Wikimedia Commons";

    imageLink.addEventListener("click", async event => {
      event.preventDefault();
      try {
        const original = await fetchOriginalUrl(item, abortController?.signal || new AbortController().signal);
        window.open(original || item.sourceUrl, "_blank", "noopener,noreferrer");
      } catch {
        window.open(item.sourceUrl, "_blank", "noopener,noreferrer");
      }
    });

    img.addEventListener("load", () => wrap.classList.add("loaded"), { once: true });
    img.addEventListener("error", () => card.remove(), { once: true });
    frag.appendChild(node);
  }
  grid.appendChild(frag);
}

function updateMeta() {
  meta.textContent = currentQuery ? `${shownCount()} · ${currentQuery}` : t("idleMeta");
}
function shownCount() { return grid.querySelectorAll(".avatar-card").length; }

async function runSearch(rawQuery, replace = true) {
  const query = SearchCore.sanitizeQuery(rawQuery);
  if (!query) {
    setStatus(t("invalid"));
    if (replace) input.focus();
    return;
  }

  if (abortController) abortController.abort();
  abortController = new AbortController();
  const id = ++requestId;
  currentQuery = query;
  currentPage = replace ? 0 : currentPage;

  if (replace) {
    grid.innerHTML = "";
    title.innerHTML = lang === "ru" ? "Ищем…" : "Searching…";
  }
  moreButton.disabled = true;
  setStatus("");
  setLoading(true);
  meta.textContent = t("looking");

  try {
    const result = await searchPage(query, currentPage, abortController.signal);
    if (id !== requestId) return;

    const fresh = result.items.filter(item => !isSeen(item));
    if (!fresh.length && result.hasMore) {
      currentPage += 1;
      const next = await searchPage(query, currentPage, abortController.signal);
      if (id !== requestId) return;
      result.items = next.items;
      result.hasMore = next.hasMore;
    }

    const batch = result.items.filter(item => !isSeen(item)).slice(0, DISPLAY_BATCH);
    batch.forEach(markSeen);
    renderCards(batch);
    hasMore = result.hasMore;

    title.innerHTML = lang === "ru" ? `Результаты для «${query}».` : `Results for “${query}”.`;
    updateMeta();
    moreButton.disabled = !hasMore;
    if (!batch.length) setStatus(t("empty"));
  } catch (error) {
    if (error.name === "AbortError") return;
    console.error(error);
    if (id !== requestId) return;
    setStatus(t("error"));
    moreButton.disabled = true;
  } finally {
    if (id === requestId) setLoading(false);
  }
}

function debounceSearch() {
  clearTimeout(debounceTimer);
  const value = input.value;
  if (SearchCore.sanitizeQuery(value).length < 3) return;
  debounceTimer = setTimeout(() => runSearch(value, true), DEBOUNCE_MS);
}

form.addEventListener("submit", event => {
  event.preventDefault();
  clearTimeout(debounceTimer);
  runSearch(input.value, true);
});
input.addEventListener("input", debounceSearch);

moreButton.addEventListener("click", async () => {
  if (!currentQuery || !hasMore) return;
  currentPage += 1;
  await runSearch(currentQuery, false);
});

document.querySelectorAll("[data-query]").forEach(button => {
  button.addEventListener("click", () => {
    input.value = button.dataset.query;
    runSearch(button.dataset.query, true);
  });
});

document.querySelectorAll(".lang").forEach(button => {
  button.addEventListener("click", () => {
    lang = button.dataset.lang;
    localStorage.setItem("imgsearch_lang", lang);
    applyLanguage();
    if (currentQuery) updateMeta();
  });
});

applyLanguage();
