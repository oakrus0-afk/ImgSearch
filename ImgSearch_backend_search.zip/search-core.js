const PRESENTATION_TERMS = new Set([
  "avatar", "avatars", "portrait", "portraits", "profile", "profiles",
  "pfp", "icon", "icons", "wallpaper", "wallpapers", "photo", "photos",
  "picture", "pictures", "image", "images", "art", "artwork", "hd", "4k"
]);

const CONNECTOR_TERMS = new Set(["of", "the", "a", "an", "and", "or", "in", "on", "for"]);

export function normalize(value) {
  return String(value ?? "")
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[–—−]/g, "-")
    .replace(/[\u0000-\u001f\u007f]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 120);
}

export function sanitizeQuery(value) {
  return normalize(value)
    .replace(/[^\p{L}\p{N}\s'&-]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function tokenizeQuery(query) {
  return sanitizeQuery(query)
    .split(/\s+/)
    .map(term => term.replace(/^-+|-+$/g, ""))
    .filter(Boolean);
}

export function compact(value) {
  return normalize(value).replace(/[\s-]+/g, "");
}

export function queryTerms(query) {
  return tokenizeQuery(query)
    .map(term => compact(term))
    .filter(Boolean);
}

export function buildSearchQueries(query) {
  const clean = sanitizeQuery(query);
  const tokens = tokenizeQuery(clean);
  const meaningful = tokens.filter(token => !CONNECTOR_TERMS.has(compact(token)));
  const entity = meaningful.filter(token => !PRESENTATION_TERMS.has(compact(token)));
  const queries = [];

  const add = value => {
    const q = sanitizeQuery(value);
    if (q && !queries.includes(q)) queries.push(q);
  };

  add(clean);
  if (entity.length) add(entity.join(" "));

  // Common punctuation variants help entity names such as Spider-Man / Spiderman
  // without making every query explode into many network requests.
  if (entity.length === 1) {
    const word = entity[0];
    if (word.toLowerCase() === "spiderman") add("spider-man");
    if (word.toLowerCase() === "spider-man") add("spiderman");
  }

  return queries.slice(0, 3);
}

function textFields(item) {
  const title = normalize(item.title);
  const description = normalize(item.description || "");
  const tags = normalize(Array.isArray(item.tags) ? item.tags.join(" ") : item.tags || "");
  const aliases = normalize(Array.isArray(item.aliases) ? item.aliases.join(" ") : item.aliases || "");
  return { title, description, tags, aliases, all: `${title} ${aliases} ${tags} ${description}`.trim() };
}

export function relevance(item, query) {
  const { title, description, tags, aliases, all } = textFields(item);
  const rawTerms = tokenizeQuery(query);
  const normalizedTerms = queryTerms(query);
  const required = normalizedTerms.filter(term => !PRESENTATION_TERMS.has(term));
  const optional = normalizedTerms.filter(term => PRESENTATION_TERMS.has(term));
  const terms = required.length ? required : normalizedTerms;

  if (!terms.length) return { score: 0, coverage: 0, matched: 0, optionalCoverage: 0 };

  const titleCompact = compact(title);
  const allCompact = compact(all);
  const phrase = compact(query);
  let score = 0;
  let matched = 0;
  let optionalMatched = 0;

  if (phrase.length >= 3 && titleCompact.includes(phrase)) score += 120;
  else if (phrase.length >= 3 && allCompact.includes(phrase)) score += 55;

  for (const term of terms) {
    const titleHit = titleCompact.includes(term);
    const tagHit = compact(tags).includes(term);
    const aliasHit = compact(aliases).includes(term);
    const descriptionHit = compact(description).includes(term);
    const hit = titleHit || tagHit || aliasHit || descriptionHit;
    if (hit) matched++;
    if (titleHit) score += 45;
    else if (aliasHit) score += 28;
    else if (tagHit) score += 24;
    else if (descriptionHit) score += 12;
  }

  for (const term of optional) {
    if (allCompact.includes(term)) optionalMatched++;
  }

  // Presentation terms refine the request; they should not make the entity disappear.
  if (optionalMatched) score += optionalMatched * 6;
  if (required.length && matched === required.length) score += 30;

  const width = Number(item.width) || 0;
  const height = Number(item.height) || 0;
  if (width >= 500 && height >= 500) score += 3;

  return {
    score,
    coverage: matched / terms.length,
    matched,
    optionalCoverage: optional.length ? optionalMatched / optional.length : 0,
    rawTerms
  };
}

export function uniqueItems(items, query = "") {
  const map = new Map();
  for (const item of items || []) {
    if (!item?.previewUrl || !item?.sourceUrl) continue;
    const key = item.id ? `${item.provider}:${item.id}` : item.previewUrl.split("?")[0];
    const old = map.get(key);
    if (!old || relevance(item, query).score > relevance(old, query).score) map.set(key, item);
  }
  return [...map.values()];
}

export function rankItems(items, query) {
  const ranked = uniqueItems(items, query)
    .map(item => ({ item, ...relevance(item, query) }))
    .sort((a, b) => b.score - a.score);

  if (!ranked.length) return [];

  // Never throw away every result merely because the API did not expose every
  // field. Require the entity terms, while presentation words remain optional.
  const minCoverage = 1;
  const good = ranked.filter(entry => entry.coverage >= minCoverage);
  return (good.length ? good : ranked.filter(entry => entry.coverage >= 0.5)).map(entry => entry.item);
}

export function createSearchResponse(query, page, items, hasMore, extra = {}) {
  return {
    ok: true,
    query: sanitizeQuery(query),
    page,
    pageSize: items.length,
    hasMore: Boolean(hasMore),
    results: items.map(item => ({
      id: item.id,
      previewUrl: item.previewUrl,
      originalUrl: item.originalUrl || null,
      sourceUrl: item.sourceUrl,
      alt: item.alt || item.title || "Image",
      title: item.title || "Image",
      description: item.description || "",
      tags: item.tags || [],
      width: item.width || 0,
      height: item.height || 0,
      provider: item.provider
    })),
    ...extra
  };
}
