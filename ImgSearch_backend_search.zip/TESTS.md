# Search test report

## Static checks
- `node --check app.js` — pass
- `node --check search-core.js` — pass
- ZIP integrity — pass

## Search-core checks
- Empty query sanitization — pass
- Repeated whitespace / punctuation sanitization — pass
- `Spiderman Avatar` => entity term `spiderman`, presentation term `avatar` — pass
- `Spider-Man Avatar` => entity term `spiderman`, presentation term `avatar` — pass
- `Spiderman` / `Spider-Man` variant generation — pass
- Title match outranks description-only match — pass
- Optional presentation term does not eliminate entity-only results — pass
- Pagination response shape — pass
- Duplicate filtering — pass

## Runtime safeguards
- 450ms debounce
- Abort previous request on a new query
- 5s network timeout
- One API request per page; fallback variants are tried only if a prior variant returns no ranked results
- Preview requests use a 500px thumbnail
- Original file URL is fetched only on result selection

## Network limitation
The build environment used to prepare this archive does not provide a reliable external network connection to Wikimedia Commons, so live API latency/results cannot be truthfully marked as verified here. The code path is covered by static and local logic tests; live API behavior must be checked from the browser where the site is deployed.
