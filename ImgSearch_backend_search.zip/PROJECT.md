# ImgSearch — project handoff

Requested changes implemented:

1. Product name changed from AvaSearch to ImgSearch.
2. EN/RU switcher added to the top-right.
3. Default result batch changed from 3 to 5.
4. Search expanded from Wikimedia-only to parallel Openverse + Wikimedia.
5. Openverse is used as an aggregator of open-licensed media sources.
6. Results are scored locally for textual relevance and avatar-friendly dimensions.
7. Duplicate suppression persists per query in localStorage.
8. More images uses the remaining ranked pool before issuing another search.
9. Search requests can be cancelled when a newer search starts.
10. Requests have a timeout so a slow provider cannot hang the interface indefinitely.
11. Images are lazy-loaded and display a lightweight loading state.
12. Responsive breakpoints cover desktop, tablet and phone layouts.
13. No API secrets are embedded in the frontend.

Quality boundary:
No web app can honestly be guaranteed bug-free on every possible device/browser without a complete device/browser matrix and production monitoring. This build avoids unnecessary dependencies and uses standard browser APIs to keep the compatibility surface small.
